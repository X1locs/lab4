﻿using System;

namespace Lab4CS
{
    class Plant
    {
        protected double _height;

        public Plant(double height)
        {
            _height = Math.Round(height, 2);
        }
 
        public override string ToString()
        {
            return "Растение";
        }

        public virtual String GetInfo()
        {
            return $"{this} высотой: {_height} м\n";
        }
    }
}
