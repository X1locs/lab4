﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4CS
{

    class Bush : Plant
    {
        private bool _isHaveFlowers;
        private int _branchesCount;

        public Bush(double height, bool isHaveFlowers, int branchesCount) : base(height)
        {
            _isHaveFlowers = isHaveFlowers;
            _branchesCount = branchesCount;
        }

        public static Bush Generate()
        {
            return new Bush(
                Form1.rnd.NextDouble() * 0.5 + 0.1,
                Form1.rnd.Next(2) == 1,
                Form1.rnd.Next(35) + 20
                );
        }

        public override string ToString()
        {
            return $"Кустарник";
        }

        public override string GetInfo()
        {
            return $"{base.GetInfo()}" +
                ((_isHaveFlowers) ? "С цветами" : "Без цветов") + "\n" +
                $"Количество веточек: {_branchesCount}";
        }
    }
}
