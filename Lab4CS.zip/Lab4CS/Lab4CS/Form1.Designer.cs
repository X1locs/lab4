﻿namespace Lab4CS
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.getButton = new System.Windows.Forms.Button();
            this.plantInfo = new System.Windows.Forms.RichTextBox();
            this.refillBtn = new System.Windows.Forms.Button();
            this.plantsCount = new System.Windows.Forms.Label();
            this.plantsList = new System.Windows.Forms.ListView();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // getButton
            // 
            this.getButton.Location = new System.Drawing.Point(12, 305);
            this.getButton.Name = "getButton";
            this.getButton.Size = new System.Drawing.Size(223, 56);
            this.getButton.TabIndex = 0;
            this.getButton.Text = "Выдать";
            this.getButton.UseVisualStyleBackColor = true;
            this.getButton.Click += new System.EventHandler(this.getButton_Click);
            // 
            // plantInfo
            // 
            this.plantInfo.Location = new System.Drawing.Point(12, 112);
            this.plantInfo.Name = "plantInfo";
            this.plantInfo.ReadOnly = true;
            this.plantInfo.Size = new System.Drawing.Size(223, 187);
            this.plantInfo.TabIndex = 1;
            this.plantInfo.Text = "";
            this.plantInfo.TextChanged += new System.EventHandler(this.plantInfo_TextChanged);
            // 
            // refillBtn
            // 
            this.refillBtn.Location = new System.Drawing.Point(12, 12);
            this.refillBtn.Name = "refillBtn";
            this.refillBtn.Size = new System.Drawing.Size(306, 42);
            this.refillBtn.TabIndex = 2;
            this.refillBtn.Text = "Перезаполнить";
            this.refillBtn.UseVisualStyleBackColor = true;
            this.refillBtn.Click += new System.EventHandler(this.refillBtn_Click);
            // 
            // plantsCount
            // 
            this.plantsCount.AutoSize = true;
            this.plantsCount.Location = new System.Drawing.Point(13, 61);
            this.plantsCount.Name = "plantsCount";
            this.plantsCount.Size = new System.Drawing.Size(0, 13);
            this.plantsCount.TabIndex = 3;
            // 
            // plantsList
            // 
            this.plantsList.HideSelection = false;
            this.plantsList.Location = new System.Drawing.Point(241, 112);
            this.plantsList.Name = "plantsList";
            this.plantsList.Size = new System.Drawing.Size(77, 249);
            this.plantsList.TabIndex = 4;
            this.plantsList.UseCompatibleStateImageBehavior = false;
            this.plantsList.SelectedIndexChanged += new System.EventHandler(this.plantsList_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(243, 61);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 45);
            this.button1.TabIndex = 5;
            this.button1.Text = "Задание";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(329, 368);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.plantsList);
            this.Controls.Add(this.plantsCount);
            this.Controls.Add(this.refillBtn);
            this.Controls.Add(this.plantInfo);
            this.Controls.Add(this.getButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button getButton;
        private System.Windows.Forms.RichTextBox plantInfo;
        private System.Windows.Forms.Button refillBtn;
        private System.Windows.Forms.Label plantsCount;
        private System.Windows.Forms.ListView plantsList;
        private System.Windows.Forms.Button button1;
    }
}

