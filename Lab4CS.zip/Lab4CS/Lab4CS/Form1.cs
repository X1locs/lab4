﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Lab4CS
{
    public partial class Form1 : Form
    {
        List<Plant> plants = new List<Plant>();
        int treesCount = 0;
        int bushsCount = 0;
        int flowersCount = 0;

        public static Random rnd = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void getButton_Click(object sender, EventArgs e)
        {
            if (plants.Count == 0)
            {
                MessageBox.Show("Машина пустая!!!");
                return;
            }

            plantInfo.Text = plants[0].GetInfo();

            if (plants[0] is Tree) treesCount--;
            else if (plants[0] is Bush) bushsCount--;
            else if (plants[0] is Flower) flowersCount--;

            plantsCount.Text = $"Деревьев: {treesCount}\n" +
                $"Кустарников: {bushsCount}\n" +
                $"Цветов: {flowersCount}\n";

            plantsList.Items.RemoveAt(0);
            plants.RemoveAt(0);
        }

        private void refillBtn_Click(object sender, EventArgs e)
        {
            plants.Clear();
            plantsList.Clear();

            treesCount = 0;
            bushsCount = 0;
            flowersCount = 0;

            for (int i=0; i < 10; i++)
            {
                switch (rnd.Next(3))
                {
                    case 0:
                        plants.Add(Tree.Generate());
                        treesCount++;
                        break;
                    case 1:
                        plants.Add(Bush.Generate());
                        bushsCount++;
                        break;
                    case 2:
                        plants.Add(Flower.Generate());
                        flowersCount++;
                        break;
                }

                plantsList.Items.Add(plants[i].ToString());
            }          

            plantsCount.Text = $"Деревьев: {treesCount}\n" +
              $"Кустарников: {bushsCount}\n" +
              $"Цветов: {flowersCount}\n";
        }

        private void plantsList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void plantInfo_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Для раздачи растений (высота)\n" +
                "- Цветы (количество лепестков, цвет, тип) \n" +
                "- Кустарники (наличие цветов, количество веточек) \n" +
                "- Деревья (высота, хвойное или листовое, радиус)");
        }
    }
}
