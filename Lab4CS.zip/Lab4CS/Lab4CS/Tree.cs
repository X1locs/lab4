﻿using System;

namespace Lab4CS
{
    class Tree : Plant
    {
        private double _radius;
        private bool _isConifers;

        public Tree(double height, double radius, bool isConifers) : base(height)
        {
            _radius = Math.Round(radius, 2);
            _isConifers = isConifers;
        }

        public static Tree Generate()
        {
            return new Tree(
                Form1.rnd.NextDouble() * 20,
                Form1.rnd.NextDouble() * 85 + 25,
                Form1.rnd.Next(2) == 1
                );
        }

        public override string ToString()
        {
            return $"Дерево {((_isConifers) ? "хвойное" : "лиственное ")}";
        }

        public override string GetInfo()
        {
            return $"{base.GetInfo()}" +
                $"Радиусом: {_radius} см\n";
        }
    }
}
