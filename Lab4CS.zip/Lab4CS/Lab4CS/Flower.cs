﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4CS
{
    enum Type
    {
        Лютик,
        Тульпан,
        Нарцисс
    }

    enum Color
    {
        Черный,
        Красный,
        Белый,
        Жёлтый
    }

    class Flower : Plant
    {
        private int _petalsCount;

        private Color _color;
        private Type _type;     

        public Flower(double height, Color color, Type type, int petalsCount) : base(height)
        {
            _color = color;
            _type = type;
            _petalsCount = petalsCount;
        }

        public static Flower Generate()
        {
            return new Flower(
                Form1.rnd.NextDouble() * 0.5 + 0.1,
                (Color)Form1.rnd.Next(4),
                (Type)Form1.rnd.Next(3),
                Form1.rnd.Next(30) + 20
                );
        }

        public override string ToString()
        {
            return $"{_color} {_type}";
        }

        public override string GetInfo()
        {
            return $"{base.GetInfo()}" + 
                $"Количество лепестков: {_petalsCount}";
        }
    }
}
